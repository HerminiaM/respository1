package Laboral;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

public class LecturaFichero {

	public LecturaFichero(){
		
	}
	private Empleado [] tabla; //tabla para guardar los empleados
	private int numEmpleados;
	
	public void tabla (int num) {
		tabla = new Empleado [num]; //creamos la tabla del tamaño indicado
		num = 0; //inicialmente no tenemos ningún contacto en la agenda
	}
	
	/*
	 * Declaramos variable para guardar los empleados
	 */
	
	Empleado emp;
	
	/*
	 * Establecemos un método para crear un nuevo empleado
	 */
	public void nuevoEmpleado (String nombre, String dni, char sexo, int categoria, int anyos) {
		emp = new Empleado(nombre, dni, sexo, categoria, anyos);
		
		}
	
	/*
	 * Escribimos un método para la lectura del fichero empleados
	 */
		public void lectura() throws Exception{
			try {
				
			FileReader fr = new FileReader("empleados.txt");
			BufferedReader f1 = new BufferedReader(fr);
			
			String linea= f1.readLine();
			
			while (linea != null) {
			// separación por comas y guardado	
				nuevoEmpleado(linea.split(";"),linea.split(";"),linea.split(";"),linea.split(";"),linea.split(";"));
			
				linea= f1.readLine();
			}
	
			f1.close(); //ya hemos procesado el fichero		
			
			} catch (EOFException eof) {
				System. out. println ("Error de fichero.");
			} catch (FileNotFoundException fnf) {	
				System. out. println ("Archivo vacío");
			}
			
			}	
		
		/*
		 * Escribimos un método para la escritura del fichero sueldo
		 */
		public void escritura() throws Exception {
			try {
				FileWriter fw = new FileWriter("sueldos.txt");
				BufferedWriter f2 = new BufferedWriter(fw);
				
				for (int i=0;i<tabla.length;i++) {
					f2.write(tabla[i].esribirEnFormato());
					f2.newLine();
				}
				
			f2.close(); //ya hemos leido el fichero de empleados
			
			} catch (EOFException eof) {
				System. out. println ("Error de fichero.");
			} catch (FileNotFoundException fnf) {	
				System. out. println ("Archivo vacío");
			}
		}
		
}	




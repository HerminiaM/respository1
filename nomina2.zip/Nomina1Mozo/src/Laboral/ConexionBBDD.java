package Laboral;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class ConexionBBDD {

	public static void main(String[] args) throws SQLException, IOException {
		
		//Creación de la conexion a la base de datos
		final String direccion = "jdbc:mysql://localhost:3306/empleado"; 
		final String usuario = "root";
		final String contrasena = "Asdfghjk1@";
		
		Connection con = DriverManager.getConnection(direccion, usuario, contrasena);
		Statement stm;
	
        //Realizamos select de la tabla
		String select = "select * from empleados";
		
		//Guardamos el resultado 
		ResultSet rs = stm.executeQuery(select);
		
		//Creamos un fichero para guardar la lectura de la bbdd
		File f = new File("misempleados");
		
		//Creamos un writter para el fichero
		FileWriter fwr = new FileWriter(f, true); //Sobreescribimos
		BufferedWriter bwr = new BufferedWriter(fwr);
		

		//Recorremos la tabla y escribimos
		while (rs.next()) {
			bwr.write(rs.getString("nombre"));
			bwr.write(" ");
			bwr.write(rs.getString("dni"));
			bwr.write(" ");
			bwr.write(rs.getChar("sexo"));
			bwr.write(" ");
			bwr.write(rs.getInt("categoria"));
			bwr.write(" ");
			bwr.write(rs.getInt("anyos"));
			bwr.write(" ");
			
			bwr.write((int) rs.getFloat("anyos"));
			bwr.write("\n");
		}

		
		//Cerramos todos los buffers, writters, conexiones
		bwr.close();
		fwr.close();
		stmt.close();
		con.close();
		
		//Creacion de un escaner para leer el fichero
		Scanner sc = new Scanner(f);
		
		//Leemos el fichero linea por linea
		while(sc.hasNext()) {
			System.out.println(sc.nextLine());
		}
		
		sc.close();
	}

}
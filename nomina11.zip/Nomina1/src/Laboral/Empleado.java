package Laboral;

public class Empleado extends Persona {
	
	private int categoria;
	private int anyos;
	
	public Empleado(String nombre, String dni, char sexo) {
		super(nombre, dni, sexo);
		this.categoria=1;
		this.anyos=0;
	}

	public Empleado(String nombre, String dni, char sexo, int categoria, int anyos) {
		super(nombre, dni, sexo);
		this.categoria=categoria;
		this.anyos=anyos;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}
	
	public int getAnyos() {
		return anyos;
	}

	public int incrAnyo () {
		int anyoTrab=anyos+1;
		return anyoTrab;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", dni=" + dni + ", sexo=" + sexo + ", categoria = " + categoria + ", anyos=" + anyos + "]";
	}




	
	
	
	
	

}

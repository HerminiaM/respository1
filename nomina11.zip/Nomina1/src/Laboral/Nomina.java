package Laboral;

public class Nomina {

	int sueldoTotal;
	
	
	private static final int SUELDO_BASE [] = {50000,70000,90000,110000,130000,150000,170000,190000,210000,230000};
	//pasamos el empleado como parametro
	public int sueldo (Empleado emp) {
		//guardamos la categoria en una variable
		
		int cat = emp.getCategoria();
		//calculamos sueldo según categoría 
		
		switch (cat) {
		case 1:
			sueldoTotal = SUELDO_BASE[0]+ (5000 * emp.getAnyos());
			break;
		case 2:
			sueldoTotal = SUELDO_BASE[1]+ (5000 * emp.getAnyos());
			break;
		case 3:
			sueldoTotal = SUELDO_BASE[2]+ (5000 * emp.getAnyos());
			break;
		case 4:
			sueldoTotal = SUELDO_BASE[3]+ (5000 * emp.getAnyos());
			break;
		case 5:
			sueldoTotal = SUELDO_BASE[4]+ (5000 * emp.getAnyos());
			break;
		case 6:
			sueldoTotal = SUELDO_BASE[5]+ (5000 * emp.getAnyos());
			break;
		case 7:
			sueldoTotal = SUELDO_BASE[6]+ (5000 * emp.getAnyos());
			break;
		case 8:
			sueldoTotal = SUELDO_BASE[7]+ (5000 * emp.getAnyos());
			break;
		case 9:
			sueldoTotal = SUELDO_BASE[8]+ (5000 * emp.getAnyos());
			break;
		case 10:
			sueldoTotal = SUELDO_BASE[9]+ (5000 * emp.getAnyos());
			break;		
		}
		
		return sueldoTotal;
	}
}


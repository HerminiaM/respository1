package Laboral;

public class CalculaNominas {
	
	Nomina nom = new Nomina();

	private void escribe (Empleado emp) {
		System.out.println("Atributos" + emp.toString());
		System.out.println("Sueldo" + nom.sueldo(emp));
		
	}
}

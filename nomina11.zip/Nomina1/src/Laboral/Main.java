package Laboral;

public class Main {

	public static void main(String[] args) {
		
		Empleado emp1 = new Empleado ("James Cosling","32000032G",'M',4,7);
		Empleado emp2 = new Empleado ("Ada Lovelace","32000031R",'F');
		Nomina nom = new Nomina();
		
		System.out.println(emp1.toString());
		System.out.println(emp2.toString());
		escribe(emp1);
		escribe (emp2);
	}
	
	private static void escribe (Empleado emp) {
		Nomina nom = new Nomina();
		System.out.println("Atributos" + emp.toString());
		System.out.println("Sueldo" + nom.sueldo(emp));

	}

}
